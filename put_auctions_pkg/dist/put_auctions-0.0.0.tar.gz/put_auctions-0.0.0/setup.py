from setuptools import setup
setup(name='put_auctions',
      py_modules=['put_auctions'],
      install_requires=['python-dateutil', 'openprocurement.auction.insider'],
      dependency_links=['http://op:x9W3jZ@dist.quintagroup.com/op/'])
